import gluoncv as gcv
from gluoncv.utils import export_block

model_name = 'ResNet50_v1'

net = gcv.model_zoo.get_model(model_name, pretrained=True)
export_block(model_name, net, preprocess=True, layout='HWC')
print('Done.')